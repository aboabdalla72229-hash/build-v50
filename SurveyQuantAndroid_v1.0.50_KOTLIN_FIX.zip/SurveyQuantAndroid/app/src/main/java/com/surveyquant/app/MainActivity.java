package com.surveyquant.app;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.content.pm.PackageManager;
import androidx.core.app.NotificationCompat;
import androidx.core.content.FileProvider;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.util.UUID;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import org.json.JSONArray;
import org.json.JSONObject;
import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> uploadCallback;
    private static final int FILE_PICKER = 1001;
    private Uri cameraUri;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new AndroidBridge(this), "Android");
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p){
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = cb;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, p != null && p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                if (p != null && p.isCaptureEnabled() && p.getAcceptTypes() != null) {
                    boolean imageCapture = false;
                    for (String t : p.getAcceptTypes()) if (t != null && t.toLowerCase().startsWith("image/")) { imageCapture = true; break; }
                    if (imageCapture) {
                        try {
                            File camDir = new File(getCacheDir(), "camera");
                            if (!camDir.exists()) camDir.mkdirs();
                            File camFile = new File(camDir, "surveyquant_camera_" + System.currentTimeMillis() + ".jpg");
                            cameraUri = FileProvider.getUriForFile(MainActivity.this, "com.surveyquant.app.fileprovider", camFile);
                            Intent cam = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                            cam.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, cameraUri);
                            cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            Intent chooser = Intent.createChooser(i, "اختر صورة من المعرض أو الكاميرا");
                            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cam});
                            startActivityForResult(chooser, FILE_PICKER);
                            return true;
                        } catch (Exception ignored) { cameraUri = null; }
                    }
                }
                try { startActivityForResult(i, FILE_PICKER); }
                catch(Exception e){ if(uploadCallback!=null) uploadCallback.onReceiveValue(null); uploadCallback=null; return false; }
                return true;
            }
        });
        setContentView(web);
        if (android.os.Build.VERSION.SDK_INT >= 23 && android.os.Build.VERSION.SDK_INT <= 28 &&
                checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 2001);
        }
        if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission("android.permission.CAMERA") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.CAMERA"}, 2003);
        }
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 2002);
        }
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d);
        if(r!=FILE_PICKER || uploadCallback==null) return;
        if(c!=RESULT_OK){ uploadCallback.onReceiveValue(null); uploadCallback=null; cameraUri=null; return; }
        if(d==null && cameraUri!=null){ Uri u=cameraUri; cameraUri=null; uploadCallback.onReceiveValue(new Uri[]{u}); uploadCallback=null; return; }
        if(d==null){ uploadCallback.onReceiveValue(null); uploadCallback=null; return; }
        try {
            if(d.getClipData()!=null){
                int n=d.getClipData().getItemCount();
                Uri[] uris=new Uri[n];
                for(int i=0;i<n;i++){ uris[i]=d.getClipData().getItemAt(i).getUri(); persistReadPermission(uris[i]); }
                uploadCallback.onReceiveValue(uris);
            } else {
                Uri u=d.getData();
                if(u!=null) persistReadPermission(u);
                uploadCallback.onReceiveValue(u!=null?new Uri[]{u}:null);
            }
        } catch(Exception e){ uploadCallback.onReceiveValue(null); }
        uploadCallback=null;
    }

    private void persistReadPermission(Uri u){
        if(u==null) return;
        try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch(Exception ignored) {}
    }

    public static class AndroidBridge {
        private static final String CHANNEL_ID = "surveyquant_downloads";
        private final Context context;
        AndroidBridge(Context c){ context=c.getApplicationContext(); }

        @JavascriptInterface
        public String saveFile(String filename, String mime, String base64) {
            try {
                String safeName = filename == null ? "SurveyQuant_Output.bin" : filename.replaceAll("[\\/:*?\"<>|\\p{Cntrl}]", "_");
                String safeMime = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
                if ("application/dxf".equalsIgnoreCase(safeMime) || "application/acad".equalsIgnoreCase(safeMime)) safeMime = "application/octet-stream";
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);

                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Downloads.MIME_TYPE, safeMime);
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SurveyQuant");
                    values.put(MediaStore.Downloads.IS_PENDING, 1);
                    Uri uri = context.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if(uri == null) return "ERROR: cannot create Downloads entry";
                    try(OutputStream out=context.getContentResolver().openOutputStream(uri)){
                        if(out == null) throw new Exception("cannot open output stream");
                        out.write(bytes);
                        out.flush();
                    }
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Downloads.IS_PENDING, 0);
                    context.getContentResolver().update(uri, done, null, null);
                    return uri.toString();
                }

                if (android.os.Build.VERSION.SDK_INT >= 23 &&
                        context.checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
                    return "ERROR: storage permission not granted";
                }
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "SurveyQuant");
                if (!dir.exists() && !dir.mkdirs()) return "ERROR: cannot create Downloads/SurveyQuant";
                File outFile = new File(dir, safeName);
                try (FileOutputStream out = new FileOutputStream(outFile)) {
                    out.write(bytes);
                    out.flush();
                }
                return FileProvider.getUriForFile(context, "com.surveyquant.app.fileprovider", outFile).toString();
            } catch(Exception e) {
                return "ERROR: " + e.getMessage();
            }
        }

        private File chunkTemp(String token) { return new File(context.getCacheDir(), "sq_chunk_" + token + ".tmp"); }
        @JavascriptInterface public String startChunkedFile(String filename,String mime){try{String token=UUID.randomUUID().toString().replace("-","");File f=chunkTemp(token);if(f.exists())f.delete();if(!f.createNewFile())return "ERROR: cannot create temp file";return token;}catch(Exception e){return "ERROR: "+e.getMessage();}}
        @JavascriptInterface public String appendChunk(String token,String base64){try{File f=chunkTemp(token);if(!f.exists())return "ERROR: temp file not found";byte[] bytes=Base64.decode(base64,Base64.DEFAULT);try(FileOutputStream out=new FileOutputStream(f,true)){out.write(bytes);out.flush();}return "OK";}catch(Exception e){return "ERROR: "+e.getMessage();}}
        @JavascriptInterface public String finishChunkedFile(String token,String filename,String mime){File f=chunkTemp(token);try{if(!f.exists())return "ERROR: temp file not found";String safeName=filename==null?"SurveyQuant_Output.bin":filename.replaceAll("[\\/:*?\"<>|\\p{Cntrl}]","_");String safeMime=(mime==null||mime.isEmpty())?"application/octet-stream":mime;if("application/dxf".equalsIgnoreCase(safeMime)||"application/acad".equalsIgnoreCase(safeMime))safeMime="application/octet-stream";Uri result;if(android.os.Build.VERSION.SDK_INT>=29){ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,safeName);v.put(MediaStore.Downloads.MIME_TYPE,safeMime);v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/SurveyQuant");v.put(MediaStore.Downloads.IS_PENDING,1);result=context.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(result==null)return "ERROR: cannot create Downloads entry";try(OutputStream out=context.getContentResolver().openOutputStream(result);FileInputStream in=new FileInputStream(f)){if(out==null)throw new Exception("cannot open output stream");byte[] buf=new byte[65536];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);out.flush();}ContentValues done=new ContentValues();done.put(MediaStore.Downloads.IS_PENDING,0);context.getContentResolver().update(result,done,null,null);}else{if(android.os.Build.VERSION.SDK_INT>=23&&context.checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE")!=PackageManager.PERMISSION_GRANTED)return "ERROR: storage permission not granted";File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"SurveyQuant");if(!dir.exists()&&!dir.mkdirs())return "ERROR: cannot create Downloads/SurveyQuant";File outFile=new File(dir,safeName);try(FileOutputStream out=new FileOutputStream(outFile);FileInputStream in=new FileInputStream(f)){byte[] buf=new byte[65536];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);out.flush();}result=FileProvider.getUriForFile(context,"com.surveyquant.app.fileprovider",outFile);}f.delete();return result.toString();}catch(Exception e){try{f.delete();}catch(Exception ignored){}return "ERROR: "+e.getMessage();}}
        @JavascriptInterface public void cancelChunkedFile(String token){try{chunkTemp(token).delete();}catch(Exception ignored){}}

        private static String jsonEscape(String s) {
            if (s == null) return "";
            return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\r", " ").replace("\n", " ");
        }

        private Bitmap loadBitmapFromBase64(String base64) throws Exception {
            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            Bitmap b = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            if (b == null) throw new Exception("الصورة غير قابلة للقراءة");
            int max = 1800;
            if (Math.max(b.getWidth(), b.getHeight()) > max) {
                float sc = max / (float)Math.max(b.getWidth(), b.getHeight());
                Bitmap n = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth()*sc)), Math.max(1, Math.round(b.getHeight()*sc)), true);
                if (n != b) b.recycle();
                b = n;
            }
            return b;
        }

        private Bitmap loadPdfPageFromBase64(String base64, int pageNo) throws Exception {
            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            File f = new File(context.getCacheDir(), "sq_pdf_" + UUID.randomUUID().toString() + ".pdf");
            try (FileOutputStream out = new FileOutputStream(f)) { out.write(bytes); }
            try (ParcelFileDescriptor fd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
                 PdfRenderer renderer = new PdfRenderer(fd)) {
                if (renderer.getPageCount() < pageNo || pageNo < 1) throw new Exception("رقم الصفحة غير موجود");
                PdfRenderer.Page page = renderer.openPage(pageNo - 1);
                float sc = Math.min(2.0f, 1800f / Math.max(page.getWidth(), page.getHeight()));
                int w = Math.max(1, Math.round(page.getWidth()*sc)), h = Math.max(1, Math.round(page.getHeight()*sc));
                Bitmap b = Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(b); c.drawColor(Color.WHITE);
                page.render(b,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                page.close();
                return b;
            } finally { try { f.delete(); } catch(Exception ignored){} }
        }

        private JSONArray detectSimpleLines(Bitmap b) {
            JSONArray out = new JSONArray();
            int w=b.getWidth(), h=b.getHeight();
            int maxW=Math.min(w,1600), maxH=Math.min(h,1600);
            int stepX=Math.max(1,w/maxW), stepY=Math.max(1,h/maxH);
            // Long dark horizontal/vertical runs. This is intentionally conservative to avoid turning text strokes into CAD lines.
            for(int y=2;y<h-2;y+=stepY){
                int run=0,start=0;
                for(int x=1;x<w;x+=stepX){
                    int c=b.getPixel(x,y); int r=Color.red(c),g=Color.green(c),bl=Color.blue(c);
                    boolean dark=(r+g+bl)<250;
                    if(dark){if(run==0)start=x;run+=stepX;} else {if(run>=Math.max(35,w/30)){try{JSONObject q=new JSONObject();q.put("type","line");q.put("x1",start);q.put("y1",y);q.put("x2",x);q.put("y2",y);out.put(q);}catch(Exception ignored){}}run=0;}
                }
            }
            for(int x=2;x<w-2;x+=stepX){
                int run=0,start=0;
                for(int y=1;y<h;y+=stepY){
                    int c=b.getPixel(x,y); int r=Color.red(c),g=Color.green(c),bl=Color.blue(c);
                    boolean dark=(r+g+bl)<250;
                    if(dark){if(run==0)start=y;run+=stepY;} else {if(run>=Math.max(35,h/30)){try{JSONObject q=new JSONObject();q.put("type","line");q.put("x1",x);q.put("y1",start);q.put("x2",x);q.put("y2",y);out.put(q);}catch(Exception ignored){}}run=0;}
                }
            }
            return out;
        }

        private String analyzeBitmap(Bitmap b, int pages) throws Exception {
            TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            Text result;
            try { result = Tasks.await(recognizer.process(InputImage.fromBitmap(b,0))); }
            finally { recognizer.close(); }
            JSONArray texts = new JSONArray();
            for(Text.TextBlock block: result.getTextBlocks()) for(Text.Line line:block.getLines()) {
                Rect r=line.getBoundingBox(); if(r==null)continue;
                JSONObject q=new JSONObject(); q.put("text",line.getText()); q.put("x",r.left); q.put("y",r.bottom); q.put("width",r.width()); q.put("height",Math.max(1,r.height())); texts.put(q);
            }
            JSONObject root=new JSONObject();
            root.put("pages",pages); root.put("width",b.getWidth()); root.put("height",b.getHeight()); root.put("texts",texts); root.put("lines",detectSimpleLines(b));
            return root.toString();
        }

        @JavascriptInterface
        public String analyzeDocument(String base64, String mime, String pageString) {
            try {
                int page=1; try{page=Math.max(1,Integer.parseInt(pageString));}catch(Exception ignored){}
                Bitmap b;
                int pages=1;
                if(mime!=null && mime.toLowerCase().contains("pdf")) {
                    byte[] bytes=Base64.decode(base64,Base64.DEFAULT);
                    File f=new File(context.getCacheDir(), "sq_pdf_count_" + UUID.randomUUID().toString() + ".pdf");
                    try(FileOutputStream out=new FileOutputStream(f)){out.write(bytes);}
                    try(ParcelFileDescriptor fd=ParcelFileDescriptor.open(f,ParcelFileDescriptor.MODE_READ_ONLY);PdfRenderer renderer=new PdfRenderer(fd)) { pages=renderer.getPageCount(); }
                    finally{try{f.delete();}catch(Exception ignored){}}
                    b=loadPdfPageFromBase64(base64,page);
                } else b=loadBitmapFromBase64(base64);
                try{return analyzeBitmap(b,pages);}finally{b.recycle();}
            } catch(Exception e) { return "ERROR: " + (e.getMessage()==null?e.toString():e.getMessage()); }
        }

        @JavascriptInterface
        public String getPdfPageCount(String base64) {
            try {
                byte[] bytes=Base64.decode(base64,Base64.DEFAULT);
                File f=new File(context.getCacheDir(), "sq_pdf_count_" + UUID.randomUUID().toString() + ".pdf");
                try(FileOutputStream out=new FileOutputStream(f)){out.write(bytes);}
                try(ParcelFileDescriptor fd=ParcelFileDescriptor.open(f,ParcelFileDescriptor.MODE_READ_ONLY);PdfRenderer renderer=new PdfRenderer(fd)){return String.valueOf(renderer.getPageCount());}
                finally{try{f.delete();}catch(Exception ignored){}}
            }catch(Exception e){return "ERROR: "+e.getMessage();}
        }

        @JavascriptInterface
        public boolean notifyDownload(String filename, String uriString, String mime) {
            try {
                String name = (filename == null || filename.trim().isEmpty()) ? "SurveyQuant_Output" : filename;
                String type = (mime == null || mime.isEmpty()) ? "*/*" : mime;
                Intent open = new Intent(Intent.ACTION_VIEW);
                open.setDataAndType(Uri.parse(uriString), type);
                open.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                int flags = android.os.Build.VERSION.SDK_INT >= 23 ?
                        android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE :
                        android.app.PendingIntent.FLAG_UPDATE_CURRENT;
                android.app.PendingIntent pending = android.app.PendingIntent.getActivity(context, Math.abs(name.hashCode()), open, flags);

                NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm == null) return false;
                if (android.os.Build.VERSION.SDK_INT >= 26) {
                    NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "تنزيلات SurveyQuant", NotificationManager.IMPORTANCE_DEFAULT);
                    ch.setDescription("إشعارات الملفات التي تم استخراجها من SurveyQuant");
                    nm.createNotificationChannel(ch);
                }
                NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                        .setSmallIcon(com.surveyquant.app.R.drawable.ic_surveyquant)
                        .setContentTitle("تم التنزيل")
                        .setContentText(name)
                        .setStyle(new NotificationCompat.BigTextStyle().bigText("تم تنزيل الملف: " + name + "\nاضغط لفتحه."))
                        .setContentIntent(pending)
                        .setAutoCancel(true)
                        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                        .setCategory(NotificationCompat.CATEGORY_PROGRESS);
                nm.notify(Math.abs((name + System.currentTimeMillis()).hashCode()), builder.build());
                return true;
            } catch(Exception e) { return false; }
        }

        @JavascriptInterface
        public boolean openFile(String uriString, String mime) {
            try {
                if(uriString==null || uriString.isEmpty()) return false;
                Intent i=new Intent(Intent.ACTION_VIEW);
                i.setDataAndType(Uri.parse(uriString), mime==null||mime.isEmpty()?"*/*":mime);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
                return true;
            } catch(Exception e){ return false; }
        }
    }

    @Override public void onBackPressed(){
        if(web != null){
            web.evaluateJavascript("(function(){if(document.body.classList.contains('project-mode')){closeProjectPage();return 'PROJECT';}var p=document.getElementById('paymentPage');if(p&&p.style.display==='block'){closePaymentPage();return 'PAYMENT';}return '';})()", value -> {
                String v = value == null ? "" : value.replace("\"", "");
                if("PROJECT".equals(v) || "PAYMENT".equals(v)) return;
                if(web.canGoBack()) web.goBack(); else MainActivity.super.onBackPressed();
            });
        } else super.onBackPressed();
    }
}
