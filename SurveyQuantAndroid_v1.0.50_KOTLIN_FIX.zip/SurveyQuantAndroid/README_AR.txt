SurveyQuant Pro - Android WebView Wrapper

النسخة الحالية تغلف SurveyQuant_Suite_PRO_V18.html داخل تطبيق Android.
Target SDK = 33، Min SDK = 23.

مهم: ملف APK النهائي غير مُضمّن لأن بيئة البناء Android SDK/Gradle غير متاحة في جلسة إنشاء الملف الحالية.
عند فتح المشروع في Android Studio أو أي بيئة Gradle، نفّذ:
./gradlew assembleDebug
وسيخرج APK داخل app/build/outputs/apk/debug/.

الدفع والـBackend:
الواجهة الحالية لا تحتوي مفاتيح دفع سرية. يجب وضع Endpoint الـBackend الحقيقي ومتغيرات البيئة الخاصة بالدفع على الخادم، وليس داخل APK.
